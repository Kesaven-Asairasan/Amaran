<?php

define( 'TOUCHUP_CORE_VERSION', '1.2' );
define( 'TOUCHUP_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'TOUCHUP_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'TOUCHUP_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'TOUCHUP_CORE_ASSETS_PATH', TOUCHUP_CORE_ABS_PATH . '/assets' );
define( 'TOUCHUP_CORE_ASSETS_URL_PATH', TOUCHUP_CORE_URL_PATH . 'assets' );
define( 'TOUCHUP_CORE_INC_PATH', TOUCHUP_CORE_ABS_PATH . '/inc' );
define( 'TOUCHUP_CORE_INC_URL_PATH', TOUCHUP_CORE_URL_PATH . 'inc' );
define( 'TOUCHUP_CORE_CPT_PATH', TOUCHUP_CORE_INC_PATH . '/post-types' );
define( 'TOUCHUP_CORE_CPT_URL_PATH', TOUCHUP_CORE_INC_URL_PATH . '/post-types' );
define( 'TOUCHUP_CORE_SHORTCODES_PATH', TOUCHUP_CORE_INC_PATH . '/shortcodes' );
define( 'TOUCHUP_CORE_SHORTCODES_URL_PATH', TOUCHUP_CORE_INC_URL_PATH . '/shortcodes' );
define( 'TOUCHUP_CORE_PLUGINS_PATH', TOUCHUP_CORE_INC_PATH . '/plugins' );
define( 'TOUCHUP_CORE_PLUGINS_URL_PATH', TOUCHUP_CORE_INC_URL_PATH . '/plugins' );
define( 'TOUCHUP_CORE_HEADER_LAYOUTS_PATH', TOUCHUP_CORE_INC_PATH . '/header/layouts' );
define( 'TOUCHUP_CORE_HEADER_LAYOUTS_URL_PATH', TOUCHUP_CORE_INC_URL_PATH . '/header/layouts' );
define( 'TOUCHUP_CORE_HEADER_ASSETS_PATH', TOUCHUP_CORE_INC_PATH . '/header/assets' );
define( 'TOUCHUP_CORE_HEADER_ASSETS_URL_PATH', TOUCHUP_CORE_INC_URL_PATH . '/header/assets' );

define( 'TOUCHUP_CORE_MENU_NAME', 'touchup_core_menu' );
define( 'TOUCHUP_CORE_OPTIONS_NAME', 'touchup_core_options' );

define( 'TOUCHUP_CORE_PROFILE_SLUG', 'mikado' );