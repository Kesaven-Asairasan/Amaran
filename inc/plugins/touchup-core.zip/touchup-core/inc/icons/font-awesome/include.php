<?php

include_once TOUCHUP_CORE_INC_PATH . '/icons/font-awesome/font-awesome.php';