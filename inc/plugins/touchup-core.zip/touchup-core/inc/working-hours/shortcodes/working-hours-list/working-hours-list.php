<?php

if ( ! function_exists( 'touchup_core_add_working_hours_list_shortcode' ) ) {
	/**
	 * Function that is adding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function touchup_core_add_working_hours_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'TouchUpCoreWorkingHoursListShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'touchup_core_filter_register_shortcodes', 'touchup_core_add_working_hours_list_shortcode' );
}

if ( class_exists( 'TouchUpCoreShortcode' ) ) {
	class TouchUpCoreWorkingHoursListShortcode extends TouchUpCoreShortcode {
		
		public function map_shortcode() {
			$this->set_shortcode_path( TOUCHUP_CORE_INC_URL_PATH . '/working-hours/shortcodes/working-hours-list' );
			$this->set_base( 'touchup_core_working_hours_list' );
			$this->set_name( esc_html__( 'Working Hours List', 'touchup-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays working hours list', 'touchup-core' ) );
			$this->set_category( esc_html__( 'TouchUp Core', 'touchup-core' ) );
			
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'touchup-core' )
			) );
			$this->set_option( array(
				'field_type'  => 'select',
				'name'        => 'working_hours_type',
				'title'       => esc_html__( 'Working hours type', 'touchup-core' ),
				'description' => esc_html__( 'When the minimal type is selected the label will display the value for Monday for the whole week', 'touchup-core' ),
				'options'     => array(
					'default' => esc_html__( 'Default', 'touchup-core' ),
					'minimal' => esc_html__( 'Minimal', 'touchup-core' )
				),
			) );
			$this->set_option( array(
				'field_type'  => 'text',
				'name'        => 'label',
				'title'       => esc_html__( 'Working hours label', 'touchup-core' ),
				'description' => esc_html__( 'Working hours label, example: weekdays, monday-friday, ...', 'touchup-core' ),
				'dependency'  => array(
					'show' => array(
						'working_hours_type' => array(
							'values' => 'minimal'
						)
					)
				)
			) );
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['holder_classes']               = $this->get_holder_classes();
			$atts['working_hours_params']         = $this->get_working_hours_params();
			$atts['working_hours_special_params'] = $this->get_working_hours_special_params();
			
			if ( $atts['working_hours_type'] === 'minimal' ) {
				
				foreach ( array( 'tuesday', 'wednesday', 'thursday', 'friday' ) as $day ) {
					unset( $atts['working_hours_params'][ $day ] );
				}
			}
			
			return touchup_core_get_template_part( 'working-hours/shortcodes/working-hours-list', 'templates/working-hours-list', $atts['working_hours_type'], $atts );
		}
		
		private function get_holder_classes() {
			$holder_classes   = $this->init_holder_classes();
			$holder_classes[] = 'qodef-working-hours-list';
			$holder_classes   = array_merge( $holder_classes );
			
			return implode( ' ', $holder_classes );
		}
		
		private function get_working_hours_params() {
			$params = array();
			
			return apply_filters( 'touchup_filter_working_hours_template_params', $params );
		}
		
		private function get_working_hours_special_params() {
			$params = array();
			
			return apply_filters( 'touchup_filter_working_hours_special_template_params', $params );
		}
	}
}