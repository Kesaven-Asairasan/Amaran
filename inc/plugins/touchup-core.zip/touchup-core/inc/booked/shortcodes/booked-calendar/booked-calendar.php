<?php

if ( ! function_exists( 'touchup_core_add_booked_calendar_shortcode' ) ) {
	/**
	 * Function that is adding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function touchup_core_add_booked_calendar_shortcode( $shortcodes ) {
		$shortcodes[] = 'TouchUpCoreBookedCalendarShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'touchup_core_filter_register_shortcodes', 'touchup_core_add_booked_calendar_shortcode' );
}

if ( class_exists( 'TouchUpCoreShortcode' ) ) {
	class TouchUpCoreBookedCalendarShortcode extends TouchUpCoreShortcode {
		
		public function map_shortcode() {
			$this->set_shortcode_path( TOUCHUP_CORE_INC_URL_PATH . '/booked/shortcodes/booked-calendar' );
			$this->set_base( 'touchup_core_booked_calendar' );
			$this->set_name( esc_html__( 'Booked Calendar', 'touchup-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays booked calendar', 'touchup-core' ) );
			$this->set_category( esc_html__( 'TouchUp Core', 'touchup-core' ) );
			
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'touchup-core' )
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'calendar_size',
				'title'      => esc_html__( 'Calendar Size', 'touchup-core' ),
				'options'    => array(
					'large' => esc_html__( 'Large', 'touchup-core' ),
					'small' => esc_html__( 'Small', 'touchup-core' )
				),
			) );
			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'calendar_skin',
				'title'      => esc_html__( 'Calendar Skin', 'touchup-core' ),
				'options'    => array(
					'' 		=> esc_html__( 'Default', 'touchup-core' ),
					'light' => esc_html__( 'Light', 'touchup-core' )
				),
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'title',
				'title'      => esc_html__( 'Title', 'touchup-core' )
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'title_tag',
				'title'         => esc_html__( 'Title Tag', 'touchup-core' ),
				'options'       => touchup_core_get_select_type_options_pool( 'title_tag' ),
				'default_value' => 'h2',
				'dependency'    => array(
					'hide' => array(
						'title' => array(
							'values' => ''
						)
					)
				),
			) );
			$this->set_option( array(
				'field_type' => 'color',
				'name'       => 'title_color',
				'title'      => esc_html__( 'Title Color', 'touchup-core' ),
				'dependency'    => array(
				'hide' => array(
					'title' => array(
						'values' => ''
					)
				)
			),
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'title_font_weight',
				'title'         => esc_html__( 'Title Font Weight', 'touchup-core' ),
				'options'       => touchup_core_get_select_type_options_pool( 'font_weight' ),
				'default_value' => '600',
				'dependency'    => array(
					'hide' => array(
						'title' => array(
							'values' => ''
						)
					)
				),
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'title_margin_bottom',
				'title'      => esc_html__( 'Title Bottom Margin (px)', 'touchup-core' ),
				'dependency'    => array(
					'hide' => array(
						'title' => array(
							'values' => ''
						)
					)
				),
			) );
			
			$this->map_extra_options();
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['holder_classes'] = $this->get_holder_classes($atts);
			$atts['title_styles']   = $this->get_title_styles( $atts );
			$atts['calendar_attrs'] = $this->get_calendar_attrs( $atts );
			
			return touchup_core_get_template_part( 'booked/shortcodes/booked-calendar', 'templates/booked-calendar-template', '', $atts );
		}
		
		private function get_holder_classes($atts) {
			$holder_classes   = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-booked-calendar';
			$holder_classes   = array_merge( $holder_classes );
			
			$holder_classes[] = ! empty($atts['calendar_skin'] ) ? 'qodef-booked--' . $atts['calendar_skin'] : '';
			
			return implode( ' ', $holder_classes );
		}
		
		private function get_title_styles( $atts ) {
			$styles = array();
			
			if ( ! empty( $atts['title_color'] ) ) {
				$styles[] = 'color: ' . $atts['title_color'];
			}
			
			if ( ! empty( $atts['title_font_weight'] ) ) {
				$styles[] = 'font-weight: ' . $atts['title_font_weight'];
			}
			
			if ( $atts['title_margin_bottom'] !== '' ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_margin_bottom'] ) ) {
					$styles[] = 'margin-bottom: ' . $atts['title_margin_bottom'];
				} else {
					$styles[] = 'margin-bottom: ' . intval( $atts['title_margin_bottom'] ) . 'px';
				}
			}
			
			return $styles;
		}
		
		private function get_calendar_attrs( $atts ) {
			$attrs = array();
			
			$attrs[] = ! empty( $atts['calendar_size'] ) ? 'size="' . esc_attr( $atts['calendar_size'] ) . '"' : '';
			
			return implode( ' ', array_filter( $attrs ) );
		}
		
	}
}