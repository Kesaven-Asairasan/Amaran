<div class="<?php echo esc_attr( $holder_classes ); ?>">
	
	<?php if ( ! empty( $title ) ) : ?>
		<?php echo '<' . touchup_core_escape_title_tag( $title_tag ); ?> class="qodef-m-appointments-title" <?php echo qode_framework_get_inline_style( $title_styles ); ?>>
		<?php echo wp_kses( $title, array( 'span' => array( 'class' => true ) ) ); ?>
		<?php echo '</' . touchup_core_escape_title_tag( $title_tag ); ?>>
	<?php endif; ?>
	
	<?php echo do_shortcode( '[booked-appointments]' ); ?>
	
</div>
