<?php

if ( ! function_exists( 'touchup_core_add_booked_appointments_shortcode' ) ) {
	/**
	 * Function that is adding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function touchup_core_add_booked_appointments_shortcode( $shortcodes ) {
		$shortcodes[] = 'TouchUpCoreBookedAppointmentsShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'touchup_core_filter_register_shortcodes', 'touchup_core_add_booked_appointments_shortcode' );
}

if ( class_exists( 'TouchUpCoreShortcode' ) ) {
	class TouchUpCoreBookedAppointmentsShortcode extends TouchUpCoreShortcode {
		
		public function map_shortcode() {
			$this->set_shortcode_path( TOUCHUP_CORE_INC_URL_PATH . '/booked/shortcodes/booked-appointments' );
			$this->set_base( 'touchup_core_booked_appointments' );
			$this->set_name( esc_html__( 'Booked Appointments', 'touchup-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays booked appointments', 'touchup-core' ) );
			$this->set_category( esc_html__( 'TouchUp Core', 'touchup-core' ) );
			
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'touchup-core' )
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'title',
				'title'      => esc_html__( 'Title', 'touchup-core' )
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'title_tag',
				'title'         => esc_html__( 'Title Tag', 'touchup-core' ),
				'options'       => touchup_core_get_select_type_options_pool( 'title_tag' ),
				'default_value' => 'h2',
				'dependency'    => array(
					'hide' => array(
						'title' => array(
							'values' => ''
						)
					)
				),
			) );
			$this->set_option( array(
				'field_type' => 'color',
				'name'       => 'title_color',
				'title'      => esc_html__( 'Title Color', 'touchup-core' ),
				'dependency'    => array(
				'hide' => array(
					'title' => array(
						'values' => ''
					)
				)
			),
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'title_font_weight',
				'title'         => esc_html__( 'Title Font Weight', 'touchup-core' ),
				'options'       => touchup_core_get_select_type_options_pool( 'font_weight' ),
				'default_value' => '600',
				'dependency'    => array(
					'hide' => array(
						'title' => array(
							'values' => ''
						)
					)
				),
			) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'title_margin_bottom',
				'title'      => esc_html__( 'Title Bottom Margin (px)', 'touchup-core' ),
				'dependency'    => array(
					'hide' => array(
						'title' => array(
							'values' => ''
						)
					)
				),
			) );
			
			$this->map_extra_options();
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			
			$atts = $this->get_atts();
			
			$atts['holder_classes'] = $this->get_holder_classes();
			$atts['title_styles']   = $this->get_title_styles( $atts );
			
			return touchup_core_get_template_part( 'booked/shortcodes/booked-appointments', 'templates/booked-appointments-template', '', $atts );
		}
		
		private function get_holder_classes() {
			$holder_classes   = $this->init_holder_classes();
			$holder_classes[] = 'qodef-booked-appointments';
			$holder_classes   = array_merge( $holder_classes );
			
			return implode( ' ', $holder_classes );
		}
		
		private function get_title_styles( $atts ) {
			$styles = array();
			
			if ( ! empty( $atts['title_color'] ) ) {
				$styles[] = 'color: ' . $atts['title_color'];
			}
			
			if ( ! empty( $atts['title_font_weight'] ) ) {
				$styles[] = 'font-weight: ' . $atts['title_font_weight'];
			}
			
			if ( $atts['title_margin_bottom'] !== '' ) {
				if ( qode_framework_string_ends_with_space_units( $atts['title_margin_bottom'] ) ) {
					$styles[] = 'margin-bottom: ' . $atts['title_margin_bottom'];
				} else {
					$styles[] = 'margin-bottom: ' . intval( $atts['title_margin_bottom'] ) . 'px';
				}
			}
			
			return $styles;
		}
	}
}