<?php

if (function_exists('touchup_core_is_booked_calendar_installed')) {
	if (touchup_core_is_booked_calendar_installed()) {
		include_once TOUCHUP_CORE_INC_PATH . '/booked/shortcodes/booked-appointments/booked-appointments.php';
	}
}