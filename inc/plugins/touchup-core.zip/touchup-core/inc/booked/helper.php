<?php

if ( ! function_exists( 'touchup_core_include_booked_shortcodes' ) ) {
	/**
	 * Function that includes shortcodes
	 */
	function touchup_core_include_booked_shortcodes() {
		foreach ( glob( TOUCHUP_CORE_INC_PATH . '/booked/shortcodes/*/include.php' ) as $shortcode ) {
			include_once $shortcode;
		}
	}
	
	add_action( 'qode_framework_action_before_shortcodes_register', 'touchup_core_include_booked_shortcodes' );
}

if ( ! function_exists( 'touchup_core_is_booked_calendar_installed' ) ) {
	/**
	 * Function that checks if Booked plugin is installed
	 * @return bool
	 *
	 * @version 0.1
	 */
	function touchup_core_is_booked_calendar_installed() {
		return defined( 'BOOKED_VERSION' );
	}
}