<?php

include_once TOUCHUP_CORE_INC_PATH . '/performance/dashboard/customizer/performance-customizer-options.php';
include_once TOUCHUP_CORE_INC_PATH . '/performance/helper.php';