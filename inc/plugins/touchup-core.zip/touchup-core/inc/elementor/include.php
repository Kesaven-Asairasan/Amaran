<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once TOUCHUP_CORE_INC_PATH .'/elementor/helper.php';
	include_once TOUCHUP_CORE_INC_PATH .'/elementor/section-handler-class.php';
}