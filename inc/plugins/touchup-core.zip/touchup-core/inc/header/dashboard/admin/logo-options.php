<?php

if ( ! function_exists( 'touchup_core_add_logo_options' ) ) {
	function touchup_core_add_logo_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'       => TOUCHUP_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'logo',
				'icon'        => 'fa fa-cog',
				'title'       => esc_html__( 'Logo', 'touchup-core' ),
				'description' => esc_html__( 'Global Logo Options', 'touchup-core' ),
				'layout'      => 'tabbed'
			)
		);

		if ( $page ) {

			$header_tab = $page->add_tab_element(
				array(
					'name'        => 'tab-header',
					'icon'        => 'fa fa-cog',
					'title'       => esc_html__( 'Header Logo Options', 'touchup-core' ),
					'description' => esc_html__( 'Set options for initial headers', 'touchup-core' )
				)
			);

			$header_tab->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_logo_height',
					'title'       => esc_html__( 'Logo Height', 'touchup-core' ),
					'description' => esc_html__( 'Enter logo height', 'touchup-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px', 'touchup-core' )
					)
				)
			);

			$header_tab->add_field_element(
				array(
					'field_type'    => 'image',
					'name'          => 'qodef_logo_main',
					'title'         => esc_html__( 'Logo - Main', 'touchup-core' ),
					'description'   => esc_html__( 'Choose main logo image', 'touchup-core' ),
					'default_value' => defined( 'TOUCHUP_ASSETS_ROOT' ) ? TOUCHUP_ASSETS_ROOT . '/img/logo.png' : '',
					'multiple'      => 'no'
				)
			);

			$header_tab->add_field_element(
				array(
					'field_type'    => 'image',
					'name'          => 'qodef_logo_dark',
					'title'         => esc_html__( 'Logo - Dark', 'touchup-core' ),
					'description'   => esc_html__( 'Choose dark logo image', 'touchup-core' ),
					'default_value' => defined( 'TOUCHUP_ASSETS_ROOT' ) ? TOUCHUP_ASSETS_ROOT . '/img/logo-dark.png' : '',
					'multiple'      => 'no'
				)
			);

			$header_tab->add_field_element(
				array(
					'field_type'    => 'image',
					'name'          => 'qodef_logo_light',
					'title'         => esc_html__( 'Logo - Light', 'touchup-core' ),
					'description'   => esc_html__( 'Choose light logo image', 'touchup-core' ),
					'default_value' => defined( 'TOUCHUP_ASSETS_ROOT' ) ? TOUCHUP_ASSETS_ROOT . '/img/logo-light.png' : '',
					'multiple'      => 'no'
				)
			);

			// Hook to include additional options after module options
			do_action( 'touchup_core_action_after_header_logo_options_map', $page, $header_tab );
		}
	}

	add_action( 'touchup_core_action_default_options_init', 'touchup_core_add_logo_options', touchup_core_get_admin_options_map_position( 'logo' ) );
}