<?php

include_once TOUCHUP_CORE_INC_PATH . '/header/scroll-appearance/fixed/helper.php';
include_once TOUCHUP_CORE_INC_PATH . '/header/scroll-appearance/fixed/dashboard/admin/fixed-header-options.php';