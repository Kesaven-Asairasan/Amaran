
<div class="qodef-divided--left">
	<div class="qodef-widget-holder">
		<?php touchup_core_get_header_widget_area( '', 'two' ); ?>
	</div>
	<?php touchup_core_template_part( 'header/layouts/divided', 'templates/parts/left-navigation' ); ?>
</div>

<?php touchup_core_get_header_logo_image(); ?>

<div class="qodef-divided--right">
	<?php touchup_core_template_part( 'header/layouts/divided', 'templates/parts/right-navigation' ); ?>
	<div class="qodef-widget-holder">
		<?php touchup_core_get_header_widget_area(); ?>
	</div>
</div>





