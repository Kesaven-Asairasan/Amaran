<?php

class DividedHeader extends TouchUpCoreHeader {
	private static $instance;

	public function __construct() {
		$this->slug = 'divided';
		$this->search_layout = 'fullscreen';
		$this->default_header_height = 90;

		parent::__construct();
	}

	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

}