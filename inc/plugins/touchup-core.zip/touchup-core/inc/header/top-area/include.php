<?php

include_once TOUCHUP_CORE_INC_PATH . '/header/top-area/top-area.php';
include_once TOUCHUP_CORE_INC_PATH . '/header/top-area/helper.php';

foreach ( glob( TOUCHUP_CORE_INC_PATH . '/header/top-area/dashboard/*/*.php' ) as $dashboard ) {
	include_once $dashboard;
}