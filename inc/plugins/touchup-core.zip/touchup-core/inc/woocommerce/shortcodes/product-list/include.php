<?php

include_once TOUCHUP_CORE_INC_PATH . '/woocommerce/shortcodes/product-list/product-list.php';

foreach ( glob( TOUCHUP_CORE_INC_PATH . '/woocommerce/shortcodes/product-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}