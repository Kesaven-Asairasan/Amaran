<?php

include_once TOUCHUP_CORE_INC_PATH . '/woocommerce/shortcodes/product-categories-list/media-custom-fields.php';
include_once TOUCHUP_CORE_INC_PATH . '/woocommerce/shortcodes/product-categories-list/product-categories-list.php';

foreach ( glob( TOUCHUP_CORE_INC_PATH . '/woocommerce/shortcodes/product-categories-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}