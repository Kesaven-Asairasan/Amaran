<?php

if ( ! function_exists( 'touchup_core_add_portfolio_single_variation_images_small' ) ) {
	function touchup_core_add_portfolio_single_variation_images_small( $variations ) {
		
		$variations['images-small'] = esc_html__( 'Images - Small', 'touchup-core' );
		
		return $variations;
	}
	
	add_filter( 'touchup_core_filter_portfolio_single_layout_options', 'touchup_core_add_portfolio_single_variation_images_small' );
}