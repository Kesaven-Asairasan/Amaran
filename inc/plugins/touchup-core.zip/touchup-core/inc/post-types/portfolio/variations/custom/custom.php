<?php

if ( ! function_exists( 'touchup_core_add_portfolio_single_variation_custom' ) ) {
	function touchup_core_add_portfolio_single_variation_custom( $variations ) {
		$variations['custom'] = esc_html__( 'Custom', 'touchup-core' );
		
		return $variations;
	}
	
	add_filter( 'touchup_core_filter_portfolio_single_layout_options', 'touchup_core_add_portfolio_single_variation_custom' );
}