<?php

get_header();

// Include cpt content template
touchup_core_template_part( 'post-types/portfolio', 'templates/content' );

get_footer();