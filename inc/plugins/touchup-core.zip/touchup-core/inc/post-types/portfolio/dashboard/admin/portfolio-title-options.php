<?php

if ( ! function_exists( 'touchup_core_add_portfolio_title_options' ) ) {
	/**
	 * Function that add title options for portfolio module
	 */
	function touchup_core_add_portfolio_title_options( $tab ) {
		
		if ( $tab ) {
			$tab->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_enable_portfolio_title',
					'title'         => esc_html__( 'Enable Title on Portfolio Single', 'touchup-core' ),
					'description'   => esc_html__( 'Use this option to enable/disable portfolio single title', 'touchup-core' ),
					'options'       => touchup_core_get_select_type_options_pool( 'yes_no' )
				)
			);

			$tab->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_portfolio_single_set_post_title_in_title_area',
					'title'         => esc_html__( 'Show Post Title in Title Area', 'touchup-core' ),
					'description'   => esc_html__( 'Enabling this option will show post title in title area on single portfolio pages', 'touchup-core' ),
					'options'       => touchup_core_get_select_type_options_pool( 'no_yes', false ),
					'default_value' => 'no',
					'dependency'    => array(
						'hide' => array(
							'qodef_enable_portfolio_title' => array(
								'values'        => 'no',
								'default_value' => ''
							)
						)
					)
				)
			);
			
			$tab->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_set_portfolio_title_area_in_grid',
					'title'         => esc_html__( 'Portfolio Title in Grid', 'touchup-core' ),
					'description'   => esc_html__( 'Enabling this option will set portfolio title area to be in grid', 'touchup-core' ),
					'options'       => touchup_core_get_select_type_options_pool( 'yes_no' )
				)
			);
		}
	}
	
	add_action( 'touchup_core_action_after_portfolio_options_single', 'touchup_core_add_portfolio_title_options' );
}