<?php

if ( ! function_exists( 'touchup_core_team_has_single' ) ) {
	function touchup_core_team_has_single() {
		return true;
	}
}

if ( ! function_exists( 'touchup_core_generate_team_single_layout' ) ) {
	function touchup_core_generate_team_single_layout() {
		$team_template = touchup_core_get_post_value_through_levels( 'qodef_team_single_layout' );
		$team_template = empty( $team_template ) ? 'default' : $team_template;
		
		return $team_template;
	}
	
	add_filter( 'touchup_core_filter_team_single_layout', 'touchup_core_generate_team_single_layout' );
}

if ( ! function_exists( 'touchup_core_get_team_holder_classes' ) ) {
	/**
	 * Function that return classes for the main team holder
	 *
	 * @return string
	 */
	function touchup_core_get_team_holder_classes() {
		$classes = array( '' );
		
		$classes[]   = 'qodef-team-single';
		
		$item_layout = touchup_core_generate_team_single_layout();
		$classes[]   = 'qodef-item-layout--' . $item_layout;
		
		return implode( ' ', $classes );
	}
}

if ( ! function_exists( 'touchup_core_generate_team_archive_with_shortcode' ) ) {
	/**
	 * Function that executes team list shortcode with params on archive pages
	 *
	 * @param string $tax - type of taxonomy
	 * @param string $tax_slug - slug of taxonomy
	 */
	function touchup_core_generate_team_archive_with_shortcode( $tax, $tax_slug ) {
		$params = array();
		
		$params['additional_params']  = 'tax';
		$params['tax']                = $tax;
		$params['tax_slug']           = $tax_slug;
		$params['layout']             = touchup_core_get_post_value_through_levels( 'qodef_team_archive_item_layout' );
		$params['behavior']           = touchup_core_get_post_value_through_levels( 'qodef_team_archive_behavior' );
		$params['columns']            = touchup_core_get_post_value_through_levels( 'qodef_team_archive_columns' );
		$params['space']              = touchup_core_get_post_value_through_levels( 'qodef_team_archive_space' );
		$params['columns_responsive'] = touchup_core_get_post_value_through_levels( 'qodef_team_archive_columns_responsive' );
		$params['columns_1440']       = touchup_core_get_post_value_through_levels( 'qodef_team_archive_columns_1440' );
		$params['columns_1366']       = touchup_core_get_post_value_through_levels( 'qodef_team_archive_columns_1366' );
		$params['columns_1024']       = touchup_core_get_post_value_through_levels( 'qodef_team_archive_columns_1024' );
		$params['columns_768']        = touchup_core_get_post_value_through_levels( 'qodef_team_archive_columns_768' );
		$params['columns_680']        = touchup_core_get_post_value_through_levels( 'qodef_team_archive_columns_680' );
		$params['columns_480']        = touchup_core_get_post_value_through_levels( 'qodef_team_archive_columns_480' );
		$params['slider_loop']        = touchup_core_get_post_value_through_levels( 'qodef_team_archive_slider_loop' );
		$params['slider_autoplay']    = touchup_core_get_post_value_through_levels( 'qodef_team_archive_slider_autoplay' );
		$params['slider_speed']       = touchup_core_get_post_value_through_levels( 'qodef_team_archive_slider_speed' );
		$params['slider_navigation']  = touchup_core_get_post_value_through_levels( 'navigation' );
		$params['slider_pagination']  = touchup_core_get_post_value_through_levels( 'pagination' );
		$params['pagination_type']    = touchup_core_get_post_value_through_levels( 'qodef_team_archive_pagination_type' );
		
		echo TouchUpCoreTeamListShortcode::call_shortcode( $params );
	}
}

if ( ! function_exists( 'touchup_core_is_team_title_enabled' ) ) {
	function touchup_core_is_team_title_enabled( $is_enabled ) {
		if ( is_singular( 'team' ) ) {
			$is_enabled = touchup_core_get_post_value_through_levels( 'qodef_enable_team_title' ) !== 'no';
		}
		
		return $is_enabled;
	}
	
	add_filter( 'touchup_filter_enable_page_title', 'touchup_core_is_team_title_enabled' );
}

if ( ! function_exists( 'touchup_core_team_title_grid' ) ) {
	function touchup_core_team_title_grid( $enable_title_grid ) {
		if( is_singular( 'team' ) ) {
			$enable_title_grid = touchup_core_get_post_value_through_levels( 'qodef_set_team_title_area_in_grid' ) !== 'no';
		}
		
		return $enable_title_grid;
	}
	
	add_filter( 'touchup_core_filter_page_title_grid', 'touchup_core_team_title_grid' );
}

if ( ! function_exists( 'touchup_core_team_breadcrumbs_title' ) ) {
	function touchup_core_team_breadcrumbs_title( $wrap_child, $settings ) {
		if ( is_tax( 'team-category' ) ) {
			$wrap_child = '';
			$category   = get_term( get_queried_object_id(), 'team-category' );
			
			if ( isset( $category->parent ) && $category->parent !== 0 ) {
				$parent     = get_term( $category->parent );
				$wrap_child .= sprintf( $settings['link'], get_term_link( $parent->term_id ), $parent->name ) . $settings['separator'];
			}
			
			$wrap_child .= sprintf( $settings['current_item'], single_cat_title( '', false ) );
		} else if ( is_singular( 'team' ) ) {
			$wrap_child = '';
			$categories = wp_get_post_terms( get_the_ID(), 'team-category' );
			
			if ( ! empty ( $categories ) ) {
				$category = $categories[0];
				if ( isset( $category->parent ) && $category->parent !== 0 ) {
					$parent     = get_term( $category->parent );
					$wrap_child .= sprintf( $settings['link'], get_term_link( $parent->term_id ), $parent->name ) . $settings['separator'];
				}
				$wrap_child .= sprintf( $settings['link'], get_term_link( $category ), $category->name ) . $settings['separator'];
			}
			
			$wrap_child .= sprintf( $settings['current_item'], get_the_title() );
		}
		
		return $wrap_child;
	}
	
	add_filter( 'touchup_core_filter_breadcrumbs_content', 'touchup_core_team_breadcrumbs_title', 10, 2 );
}

if ( ! function_exists( 'touchup_core_set_team_custom_sidebar_name' ) ) {
	/**
	 * Function that return sidebar name
	 *
	 * @param $sidebar_name string
	 *
	 * @return string
	 */
	function touchup_core_set_team_custom_sidebar_name( $sidebar_name ) {
		
		if( is_singular( 'team' ) ) {
			$option = touchup_core_get_post_value_through_levels( 'qodef_team_single_custom_sidebar' );
		} else if ( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'team' );
			
			foreach ( $taxonomies as $tax ) {
				if ( is_tax( $tax ) ) {
					$option = touchup_core_get_post_value_through_levels( 'qodef_team_archive_custom_sidebar' );
				}
			}
		}
		
		if ( isset( $option ) && ! empty( $option ) ) {
			$sidebar_name = $option;
		}
		
		return $sidebar_name;
	}
	
	add_filter( 'touchup_filter_sidebar_name', 'touchup_core_set_team_custom_sidebar_name' );
}

if ( ! function_exists( 'touchup_core_set_team_sidebar_layout' ) ) {
	/**
	 * Function that return sidebar layout
	 *
	 * @param $layout string
	 *
	 * @return string
	 */
	function touchup_core_set_team_sidebar_layout( $layout ) {
		
		if( is_singular( 'team' ) ) {
			$option = touchup_core_get_post_value_through_levels( 'qodef_team_single_sidebar_layout' );
		} else if( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'team' );
			foreach ( $taxonomies as $tax ) {
				if( is_tax( $tax ) ) {
					$option = touchup_core_get_post_value_through_levels( 'qodef_team_archive_sidebar_layout' );
				}
			}
		}
		
		if ( isset( $option ) && ! empty( $option ) ) {
			$layout = $option;
		}
		
		return $layout;
	}
	
	add_filter( 'touchup_filter_sidebar_layout', 'touchup_core_set_team_sidebar_layout' );
}

if ( ! function_exists( 'touchup_core_set_team_sidebar_grid_gutter_classes' ) ) {
	/**
	 * Function that returns grid gutter classes
	 *
	 * @param $classes string
	 *
	 * @return string
	 */
	function touchup_core_set_team_sidebar_grid_gutter_classes( $classes ) {
		
		if( is_singular( 'team' ) ) {
			$option = touchup_core_get_post_value_through_levels( 'qodef_team_single_sidebar_grid_gutter' );
		} else if( is_tax() ) {
			$taxonomies = get_object_taxonomies( 'team' );
			foreach ( $taxonomies as $tax ) {
				if( is_tax( $tax ) ) {
					$option = touchup_core_get_post_value_through_levels( 'qodef_team_archive_sidebar_grid_gutter' );
				}
			}
		}
		if ( isset( $option ) && ! empty( $option ) ) {
			$classes = 'qodef-gutter--' . esc_attr( $option );
		}
		
		return $classes;
	}
	
	add_filter('touchup_filter_grid_gutter_classes', 'touchup_core_set_team_sidebar_grid_gutter_classes');
}

if ( ! function_exists( 'touchup_core_team_set_admin_options_map_position' ) ) {
	/**
	 * Function that set dashboard admin options map position for this module
	 *
	 * @param $position int
	 * @param $map string
	 *
	 * @return int
	 */
	function touchup_core_team_set_admin_options_map_position( $position, $map ) {
		
		if ( $map === 'team' ) {
			$position = 52;
		}
		
		return $position;
	}
	
	add_filter( 'touchup_core_filter_admin_options_map_position', 'touchup_core_team_set_admin_options_map_position', 10, 2 );
}

if ( ! function_exists( 'touchup_core_get_hours_range' ) ) {
	/**
	 * Returns array of hours range
	 *
	 * @param $params array - config param
	 *
	 * @return array
	 */
	function touchup_core_get_hours_range( $params = array() ) {
		// Default values
		$start  = 0;
		$end    = 86400;
		$step   = 1800;
		$format = 'g:ia';

		extract( $params );

		$times = array();

		foreach ( range( $start, $end, $step ) as $timestamp ) {
			$hour = gmdate( $format, $timestamp );

			$times[ $hour ] = $hour;
		}

		return $times;
	}
}

if ( ! function_exists( 'touchup_core_get_json_workdays_list' ) ) {
	/**
	 * Returns list of workdays in Json format
	 *
	 * @param $params array - config param
	 *
	 * @return string
	 */
	function touchup_core_get_json_workdays_list( $params = array() ) {

		if ( ! is_array( $params ) ) {
			$params = array();
		}

		$days = array(
			'monday'    => 1,
			'tuesday'   => 2,
			'wednesday' => 3,
			'thursday'  => 4,
			'friday'    => 5,
			'saturday'  => 6,
			'sunday'    => 7,
		);

		$workdays_list = array();
		foreach ( $params as $param ) {
			if ( array_key_exists( $param, $days ) ) {
				$workdays_list[] = $days[ $param ];
			}
		}

		return json_encode( $workdays_list );
	}
}

if ( ! function_exists( 'touchup_core_get_worktime_list' ) ) {
	/**
	 * Returns worktime list
	 *
	 * @param $params array - config param
	 *
	 * @return array
	 */
	function touchup_core_get_worktime_list( $params = array() ) {

		if ( ! is_array( $params ) ) {
			$params = array();
		}

		return array_values( touchup_core_get_hours_range( $params ) );
	}
}

if ( ! function_exists( 'touchup_core_add_rest_api_team_booking_global_variables' ) ) {
	function touchup_core_add_rest_api_team_booking_global_variables( $global, $namespace ) {
		$global['teamBookingRestRoute'] = $namespace . '/team-booking';
		$global['teamBookingNonce']     = wp_create_nonce( 'wp_rest' );

		return $global;
	}

	add_filter( 'touchup_filter_rest_api_global_variables', 'touchup_core_add_rest_api_team_booking_global_variables', 10, 2 );
}

if ( ! function_exists( 'touchup_core_add_rest_api_team_booking_route' ) ) {
	function touchup_core_add_rest_api_team_booking_route( $routes ) {
		$routes['team-booking'] = array(
			'route'    => 'team-booking',
			'methods'  => WP_REST_Server::CREATABLE,
			'callback' => 'touchup_core_action_send_single_booking_form',
			'args'     => array(
				'options' => array(
					'required'          => true,
					'validate_callback' => function ( $param, $request, $key ) {
						// Simple solution for validation can be 'is_array' value instead of callback function
						return is_array( $param ) ? $param : (array) $param;
					},
					'description'       => esc_html__( 'Options data is array with all team booking parameters value', 'touchup-core' )
				)
			)
		);

		return $routes;
	}

	add_filter( 'touchup_filter_rest_api_routes', 'touchup_core_add_rest_api_team_booking_route' );
}


if ( ! function_exists( 'touchup_core_action_send_single_booking_form' ) ) {

    function touchup_core_action_send_single_booking_form() {

        if ( isset($_POST['options']) ) {

            $error = false;
            $responseMessage = '';

            $email_data = $_POST['options'];

            //Validate

	        if ( ! $error ) {

		        if ( $email_data['member'] ) {
			        $member = esc_html( $email_data['member'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please select a member', 'touchup-core' );
		        }
	        }

	        if ( ! $error ) {

		        if ( $email_data['name'] ) {
			        $name = esc_html( $email_data['name'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please insert valid name', 'touchup-core' );
		        }
	        }

	        if ( ! $error ) {

		        if ( $email_data['contact'] ) {
			        $phone = esc_html( $email_data['contact'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please insert valid phone', 'touchup-core' );
		        }
	        }

	        if ( ! $error ) {

		        if ( $email_data['date'] ) {
			        $date = esc_html( $email_data['date'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please choose a valid date', 'touchup-core' );
		        }
	        }

	        if ( ! $error ) {

		        if ( $email_data['time'] ) {
			        $time = esc_html( $email_data['time'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please choose a valid time', 'touchup-core' );
		        }
	        }

            //Send Mail and response
            if ( $error ) {

                wp_send_json_error( $responseMessage );

            } else {

                //Get email address
                $mail_to = touchup_core_get_post_value_through_levels( 'qodef_team_booking_email' );
                if ($mail_to == '') {
                    $mail_to = get_option('admin_email');
                }

                $headers = array();

                $messageTemplate = '';

	            $messageTemplate .= esc_html__('Member', 'touchup-core') . ': ' . $member . "\r\n\n";
	            $messageTemplate .= esc_html__('From', 'touchup-core'). ': ' . $name . "\r\n";
                $messageTemplate .= esc_html__('Phone', 'touchup-core') . ': ' . $phone . "\r\n";
                $messageTemplate .= esc_html__('Requested date', 'touchup-core'). ': ' . $date . "\r\n";
                $messageTemplate .= esc_html__('Requested time', 'touchup-core') . ': ' . $time . "\r\n\n";

                $mail_sent = wp_mail(
                    $mail_to, //Mail To
                    esc_html__('New Booking Request', 'touchup-core'), //Subject
                    $messageTemplate, //Message
                    $headers //Additional Headers
                );

                if ($mail_sent) {
                    $responseMessage = esc_html__('Booking request sent successfully', 'touchup-core');
                    wp_send_json_success( $responseMessage );
                }
                else {
                    $responseMessage = esc_html__('Booking request failed. Please try later.', 'touchup-core');
                    wp_send_json_error( $responseMessage );
                }
            }

        } else {
            $message = esc_html__('Please review your enquiry and send again', 'touchup-core');
            wp_send_json_error( $message );
        }

    }

}

if ( ! function_exists( 'touchup_core_add_rest_api_booking_form_global_variables' ) ) {
	function touchup_core_add_rest_api_booking_form_global_variables( $global, $namespace ) {
		$global['bookingFormRestRoute'] = $namespace . '/booking-form';
		$global['bookingFormNonce']     = wp_create_nonce( 'wp_rest' );

		return $global;
	}

	add_filter( 'touchup_filter_rest_api_global_variables', 'touchup_core_add_rest_api_booking_form_global_variables', 10, 2 );
}

if ( ! function_exists( 'touchup_core_add_rest_api_booking_form_route' ) ) {
	function touchup_core_add_rest_api_booking_form_route( $routes ) {
		$routes['booking-form'] = array(
			'route'    => 'booking-form',
			'methods'  => WP_REST_Server::CREATABLE,
			'callback' => 'touchup_core_action_send_booking_form',
			'args'     => array(
				'options' => array(
					'required'          => true,
					'validate_callback' => function ( $param, $request, $key ) {
						// Simple solution for validation can be 'is_array' value instead of callback function
						return is_array( $param ) ? $param : (array) $param;
					},
					'description'       => esc_html__( 'Options data is array with all booking form parameters value', 'touchup-core' )
				)
			)
		);

		return $routes;
	}

	add_filter( 'touchup_filter_rest_api_routes', 'touchup_core_add_rest_api_booking_form_route' );
}


if ( ! function_exists( 'touchup_core_action_send_booking_form' ) ) {

    function touchup_core_action_send_booking_form() {

        if ( isset($_POST['options']) ) {

            $error = false;
            $responseMessage = '';

            $email_data = $_POST['options'];

            //Validate

	        if ( ! $error ) {

		        if ( $email_data['category'] ) {
			        $category = esc_html( $email_data['category'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please select a category', 'touchup-core' );
		        }
	        }

	        if ( ! $error ) {

		        if ( $email_data['member'] ) {
			        $member = esc_html( $email_data['member'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please select a member', 'touchup-core' );
		        }
	        }

	        if ( ! $error ) {

		        if ( $email_data['date'] ) {
			        $date = esc_html( $email_data['date'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please choose a valid date', 'touchup-core' );
		        }
	        }

	        if ( ! $error ) {

		        if ( $email_data['time'] ) {
			        $time = esc_html( $email_data['time'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please choose a valid time', 'touchup-core' );
		        }
	        }

	        if ( ! $error ) {

		        if ( $email_data['name'] ) {
			        $name = esc_html( $email_data['name'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please insert valid name', 'touchup-core' );
		        }
	        }

	        if ( ! $error ) {

		        if ( $email_data['email'] ) {
			        $email = esc_html( $email_data['email'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please insert valid email', 'touchup-core' );
		        }
	        }

	        if ( ! $error ) {

		        if ( $email_data['contact'] ) {
			        $phone = esc_html( $email_data['contact'] );
		        } else {
			        $error           = true;
			        $responseMessage = esc_html__( 'Please insert valid phone', 'touchup-core' );
		        }
	        }

            //Send Mail and response
            if ( $error ) {

                wp_send_json_error( $responseMessage );

            } else {

                //Get email address
                $mail_to = touchup_core_get_post_value_through_levels( 'qodef_team_booking_email' );
                if ($mail_to == '') {
                    $mail_to = get_option('admin_email');
                }

                $headers = array();

                $messageTemplate = '';

	            $messageTemplate .= esc_html__('Category', 'touchup-core') . ': ' . $category . "\r\n";
	            $messageTemplate .= esc_html__('Member', 'touchup-core') . ': ' . $member . "\r\n\n";
	            $messageTemplate .= esc_html__('From', 'touchup-core'). ': ' . $name . "\r\n";
                $messageTemplate .= esc_html__('Email', 'touchup-core') . ': ' . $email . "\r\n";
                $messageTemplate .= esc_html__('Phone', 'touchup-core') . ': ' . $phone . "\r\n";
                $messageTemplate .= esc_html__('Requested date', 'touchup-core'). ': ' . $date . "\r\n";
                $messageTemplate .= esc_html__('Requested time', 'touchup-core') . ': ' . $time . "\r\n\n";

                $mail_sent = wp_mail(
                    $mail_to, //Mail To
                    esc_html__('New Booking Request', 'touchup-core'), //Subject
                    $messageTemplate, //Message
                    $headers //Additional Headers
                );

                if ($mail_sent) {
                    $responseMessage = esc_html__('Booking request sent successfully', 'touchup-core');
                    wp_send_json_success( $responseMessage );
                }
                else {
                    $responseMessage = esc_html__('Booking request failed. Please try later.', 'touchup-core');
                    wp_send_json_error( $responseMessage );
                }
            }

        } else {
            $message = esc_html__('Please review your enquiry and send again', 'touchup-core');
            wp_send_json_error( $message );
        }

    }

}