<?php

include_once TOUCHUP_CORE_INC_PATH . '/content/helper.php';