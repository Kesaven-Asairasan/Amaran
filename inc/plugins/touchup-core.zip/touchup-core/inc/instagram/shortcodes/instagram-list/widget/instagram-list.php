<?php

if ( ! function_exists( 'touchup_core_add_instagram_list_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param $widgets array
	 *
	 * @return array
	 */
	function touchup_core_add_instagram_list_widget( $widgets ) {
		if ( qode_framework_is_installed( 'instagram' ) ) {
			$widgets[] = 'TouchUpCoreInstagramListWidget';
		}

		return $widgets;
	}

	add_filter( 'touchup_core_filter_register_widgets', 'touchup_core_add_instagram_list_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class TouchUpCoreInstagramListWidget extends QodeFrameworkWidget {

		public function map_widget() {
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'widget_title',
					'title'      => esc_html__( 'Title', 'touchup-core' ),
				)
			);
			$widget_mapped = $this->import_shortcode_options(
				array(
					'shortcode_base' => 'touchup_core_instagram_list',
				)
			);
			if ( $widget_mapped ) {
				$this->set_base( 'touchup_core_instagram_list' );
				$this->set_name( esc_html__( 'TouchUp Instagram List', 'touchup-core' ) );
				$this->set_description( esc_html__( 'Add a instagram list element into widget areas', 'touchup-core' ) );
			}
		}

		public function render( $atts ) {
			echo TouchUpCoreInstagramListShortcode::call_shortcode( $atts ); // XSS OK
		}
	}
}
