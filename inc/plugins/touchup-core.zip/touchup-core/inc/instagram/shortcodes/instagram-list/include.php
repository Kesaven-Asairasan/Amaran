<?php

include_once TOUCHUP_CORE_INC_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once TOUCHUP_CORE_INC_PATH . '/instagram/shortcodes/instagram-list/instagram-list.php';
