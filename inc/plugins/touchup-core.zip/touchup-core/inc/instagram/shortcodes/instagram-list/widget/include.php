<?php

include_once TOUCHUP_CORE_INC_PATH . '/instagram/shortcodes/instagram-list/widget/instagram-list.php';
