<?php

include_once TOUCHUP_CORE_INC_PATH . '/mobile-header/mobile-header.php';
include_once TOUCHUP_CORE_INC_PATH . '/mobile-header/mobile-headers.php';
include_once TOUCHUP_CORE_INC_PATH . '/mobile-header/template-functions.php';