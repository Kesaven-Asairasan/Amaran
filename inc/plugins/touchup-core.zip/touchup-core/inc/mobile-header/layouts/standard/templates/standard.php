<?php
// Include mobile logo
touchup_core_get_mobile_header_logo_image();

// Include mobile haeder widget area
dynamic_sidebar( 'qodef-mobile-header-widget-area' );

// Include mobile navigation opener
touchup_core_template_part( 'mobile-header', 'templates/parts/mobile-navigation-opener' );

// Include mobile navigation
touchup_core_template_part( 'mobile-header', 'templates/parts/mobile-navigation' );