<?php

if ( ! function_exists( 'touchup_core_add_map_options' ) ) {
	/**
	 * Function that add map options
	 */
	function touchup_core_add_map_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'       => TOUCHUP_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'map',
				'icon'        => 'fa fa-book',
				'title'       => esc_html__( 'Maps', 'touchup-core' ),
				'description' => esc_html__( 'Global Maps Options', 'touchup-core' )
			)
		);

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_maps_api_key',
					'title'       => esc_html__( 'Maps API Key', 'touchup-core' ),
					'description' => esc_html__( 'Enter Google Maps API key', 'touchup-core' )
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'textarea',
					'name'        => 'qodef_map_style',
					'title'       => esc_html__( 'Map Style', 'touchup-core' ),
					'description' => esc_html__( 'Enter Snazzy Map style JSON code', 'touchup-core' )
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_map_zoom',
					'title'       => esc_html__( 'Map Zoom', 'touchup-core' ),
					'description' => esc_html__( 'Enter default zoom value for map', 'touchup-core' )
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_map_scroll',
					'title'         => esc_html__( 'Enable Map Scroll', 'touchup-core' ),
					'description'   => esc_html__( 'Use this option to enable map scrolling', 'touchup-core' ),
					'default_value' => 'no'
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_map_drag',
					'title'         => esc_html__( 'Enable Map Dragging', 'touchup-core' ),
					'description'   => esc_html__( 'Use this option to enable map dragging', 'touchup-core' ),
					'default_value' => 'yes'
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_map_street_view_control',
					'title'         => esc_html__( 'Enable Map Street View Control', 'touchup-core' ),
					'description'   => esc_html__( 'Use this option to enable street view control on map', 'touchup-core' ),
					'default_value' => 'yes'
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_map_zoom_control',
					'title'         => esc_html__( 'Enable Map Zoom Control', 'touchup-core' ),
					'description'   => esc_html__( 'Use this option to enable zoom control on map', 'touchup-core' ),
					'default_value' => 'yes'
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_map_type_control',
					'title'         => esc_html__( 'Enable Map Type Control', 'touchup-core' ),
					'description'   => esc_html__( 'Use this option to enable type control on map', 'touchup-core' ),
					'default_value' => 'yes'
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_enable_map_full_screen_control',
					'title'         => esc_html__( 'Enable Map Full Screen Control', 'touchup-core' ),
					'description'   => esc_html__( 'Use this option to enable full screen control on map', 'touchup-core' ),
					'default_value' => 'yes'
				)
			);

			// Hook to include additional options after module options
			do_action( 'touchup_core_action_after_map_options_map', $page );
		}
	}

	add_action( 'touchup_core_action_default_options_init', 'touchup_core_add_map_options', touchup_core_get_admin_options_map_position( 'maps' ) );
}