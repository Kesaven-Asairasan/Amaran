<?php

if ( ! function_exists( 'touchup_core_include_role_custom_fields' ) ) {
	/**
	 * Function that includes role custom fields files
	 */
	function touchup_core_include_role_custom_fields() {
		foreach ( glob( TOUCHUP_CORE_INC_PATH . '/roles/*/role-fields.php' ) as $role_fields ) {
			include_once $role_fields;
		}
	}
	
	add_action( 'qode_framework_action_custom_user_fields', 'touchup_core_include_role_custom_fields' );
}

if ( ! function_exists( 'touchup_core_register_role_custom_fields' ) ) {
	/**
	 * Function that registers role custom fields files
	 */
	function touchup_core_register_role_custom_fields() {
		do_action( 'touchup_core_action_register_role_custom_fields' );
	}
	
	add_action( 'qode_framework_action_custom_user_fields', 'touchup_core_register_role_custom_fields', 11 );
}

if ( ! function_exists( 'touchup_core_add_user_custom_fields' ) ) {
	/**
	 * Function creates custom fields for users
	 *
	 * return $user_contact
	 */
	function touchup_core_add_user_custom_fields( $user_contact ) {
		/**
		 * Function that add custom user fields
		 **/
		$user_contact['degree']   = esc_html__( 'Degree', 'touchup-core' );
		$user_contact['position'] = esc_html__( 'Position', 'touchup-core' );
		
		return $user_contact;
	}
	
	add_filter( 'user_contactmethods', 'touchup_core_add_user_custom_fields' );
}