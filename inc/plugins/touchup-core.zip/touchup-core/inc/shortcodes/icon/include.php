<?php

include_once TOUCHUP_CORE_SHORTCODES_PATH . '/icon/icon.php';