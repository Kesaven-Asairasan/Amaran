<?php

include_once TOUCHUP_CORE_SHORTCODES_PATH . '/icon/widget/icon.php';