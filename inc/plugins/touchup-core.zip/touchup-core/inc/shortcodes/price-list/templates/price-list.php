<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-m-items">
		<?php foreach ( $items as $item ) { ?>
			<div class="qodef-m-item">
				<span class="qodef-m-item-title"><?php echo esc_html( $item['item_title'] ); ?></span>
				<span class="qodef-m-item-price"><?php echo esc_html( $item['item_price'] ); ?></span>
			</div>
		<?php } ?>
	</div>
</div>