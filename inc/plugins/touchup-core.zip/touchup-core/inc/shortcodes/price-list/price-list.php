<?php

if ( ! function_exists( 'touchup_core_add_price_list_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param $shortcodes array
	 *
	 * @return array
	 */
	function touchup_core_add_price_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'TouchUpCorePriceListShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'touchup_core_filter_register_shortcodes', 'touchup_core_add_price_list_shortcode' );
}

if ( class_exists( 'TouchUpCoreShortcode' ) ) {
	class TouchUpCorePriceListShortcode extends TouchUpCoreShortcode {

		public function map_shortcode() {
			$this->set_shortcode_path( TOUCHUP_CORE_SHORTCODES_URL_PATH . '/price-list' );
			$this->set_base( 'touchup_core_price_list' );
			$this->set_name( esc_html__( 'Price List', 'touchup-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds price list holder', 'touchup-core' ) );
			$this->set_category( esc_html__( 'TouchUp Core', 'touchup-core' ) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'touchup-core' ),
			) );

			$this->set_option( array(
				'field_type' => 'select',
				'name'       => 'skin',
				'title'      => esc_html__( 'Link Skin', 'touchup-core' ),
				'options'    => array(
					''      => esc_html__( 'Default', 'touchup-core' ),
					'light' => esc_html__( 'Light', 'touchup-core' )
				)
			) );
			$this->set_option( array(
				'field_type' => 'repeater',
				'name'       => 'children',
				'title'      => esc_html__( 'Child elements', 'touchup-core' ),
				'items'   => array(
					array(
						'field_type' => 'text',
						'name'       => 'item_title',
						'title'      => esc_html__( 'Title', 'touchup-core' )
					),
					array(
						'field_type' => 'text',
						'name'       => 'item_price',
						'title'      => esc_html__( 'Price', 'touchup-core' )
					)
				)
			) );
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();
			
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['items']          = $this->parse_repeater_items( $atts['children'] );

			return touchup_core_get_template_part( 'shortcodes/price-list', 'templates/price-list', '', $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-price-list';
			$holder_classes[] = ! empty( $atts['skin'] ) ? 'qodef-skin--' . $atts['skin'] : '';
			
			return implode( ' ', $holder_classes );
		}
	}
}