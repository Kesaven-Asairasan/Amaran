<?php

include_once TOUCHUP_CORE_SHORTCODES_PATH . '/helper.php';
include_once TOUCHUP_CORE_SHORTCODES_PATH . '/shortcodes.php';