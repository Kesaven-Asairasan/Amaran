<?php

include_once TOUCHUP_CORE_SHORTCODES_PATH . '/before-after/before-after.php';

foreach ( glob( TOUCHUP_CORE_INC_PATH . '/shortcodes/before-after/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}