<?php

if ( ! function_exists( 'touchup_core_add_before_after_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param $shortcodes array
	 *
	 * @return array
	 */
	function touchup_core_add_before_after_shortcode( $shortcodes ) {
		$shortcodes[] = 'TouchUpCoreBeforeAfterShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'touchup_core_filter_register_shortcodes', 'touchup_core_add_before_after_shortcode' );
}

if ( class_exists( 'TouchUpCoreShortcode' ) ) {
	class TouchUpCoreBeforeAfterShortcode extends TouchUpCoreShortcode {
		
		public function __construct() {
			$this->set_extra_options( apply_filters( 'touchup_core_filter_before_after_extra_options', array() ) );
			
			parent::__construct();
		}
		
		public function map_shortcode() {
			$this->set_shortcode_path( TOUCHUP_CORE_SHORTCODES_URL_PATH . '/before-after' );
			$this->set_base( 'touchup_core_before_after' );
			$this->set_name( esc_html__( 'Comparison Slider', 'touchup-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds comparison slider element', 'touchup-core' ) );
			$this->set_category( esc_html__( 'TouchUp Core', 'touchup-core' ) );

			$this->set_scripts(
				array(
					'twentytwenty' => array(
						'registered'	=> false,
						'url'			=> TOUCHUP_CORE_SHORTCODES_URL_PATH . '/before-after/assets/js/plugins/jquery.twentytwenty.js',
						'dependency'	=> array( 'jquery', 'jquery-effects-core' ),
						'version'       => false,
						'footer'        => true
					),
					'event-move' => array(
						'registered'	=> false,
						'url'			=> TOUCHUP_CORE_SHORTCODES_URL_PATH . '/before-after/assets/js/plugins/jquery.event.move.js',
						'dependency'	=> array( 'jquery', 'jquery-effects-core' ),
						'version'       => false,
						'footer'        => true
					)
				)
			);

			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'touchup-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'image',
				'name'       => 'image_before',
				'title'      => esc_html__( 'Image Before', 'touchup-core' ),
			) );
			$this->set_option( array(
				'field_type' => 'image',
				'name'       => 'image_after',
				'title'      => esc_html__( 'Image After', 'touchup-core' ),
			) );
			$this->set_option( array(
				'field_type'  => 'text',
				'name'        => 'offset',
				'title'       => esc_html__( 'Default Offset', 'touchup-core' ),
				'description' => esc_html__( 'Default value is 50 (%)', 'touchup-core' )
			) );
			
			$this->map_extra_options();
		}
		
		public function load_assets() {
			wp_enqueue_script( 'jquery-effects-core' );
			
			wp_enqueue_script( 'twentytwenty' );
			wp_enqueue_script( 'event-move' );
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();
			
			$atts['offset'] = doubleval( $atts['offset'] );
			if ($atts['offset'] < 0 || $atts['offset'] > 100) {
				$atts['offset'] = 50;
			}
			
			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['holder_data']    = $this->getHolderData( $atts );
			
			return touchup_core_get_template_part( 'shortcodes/before-after', 'templates/before-after-template', '', $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-before-after';
			
			return implode( ' ', $holder_classes );
		}
		
		private function getHolderData( $atts ) {
			$holder_data = array();
			
			$holder_data['data-offset']      = ! empty( $atts['offset'] ) ? esc_attr( $atts['offset'] ) : 50;
			
			return $holder_data;
		}
	}
}