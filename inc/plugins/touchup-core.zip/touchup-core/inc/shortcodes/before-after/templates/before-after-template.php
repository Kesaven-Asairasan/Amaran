<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="before-after-image-holder qodef-m-image" <?php echo qode_framework_get_inline_attrs($holder_data); ?>>
		<?php echo wp_get_attachment_image( $image_before, 'full' ); ?>
		<?php echo wp_get_attachment_image( $image_after, 'full' ); ?>
	</div>
</div>