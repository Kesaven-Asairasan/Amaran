<?php

if ( ! function_exists( 'touchup_core_add_icon_with_text_list_shortcode' ) ) {
	/**
	 * Function that isadding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function touchup_core_add_icon_with_text_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'TouchUpCoreIconWithTextListShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'touchup_core_filter_register_shortcodes', 'touchup_core_add_icon_with_text_list_shortcode' );
}

if ( class_exists( 'TouchUpCoreListShortcode' ) ) {
	class TouchUpCoreIconWithTextListShortcode extends TouchUpCoreListShortcode {
		
		public function __construct() {
			$this->set_extra_options( apply_filters( 'touchup_core_filter_icon_with_text_list_extra_options', array() ) );

			parent::__construct();
		}
		
		public function map_shortcode() {
			$this->set_shortcode_path( TOUCHUP_CORE_SHORTCODES_URL_PATH . '/icon-with-text-list' );
			$this->set_base( 'touchup_core_icon_with_text_list' );
			$this->set_name( esc_html__( 'Icon With Text List', 'touchup-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays icon with text list', 'touchup-core' ) );
			$this->set_category( esc_html__( 'TouchUp Core', 'touchup-core' ) );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'custom_class',
				'title'      => esc_html__( 'Custom Class', 'touchup-core' )
			) );
			$this->set_option( array(
				'field_type'    => 'select',
				'name'          => 'columns',
				'title'         => esc_html__( 'Number of Columns', 'touchup-core' ),
				'options'       => array(
					'3' => esc_html__( 'Three', 'touchup-core' ),
					'4' => esc_html__( 'Four', 'touchup-core' )
				),
				'default_value' => '3'
			) );
			$this->set_option( array(
				'field_type' => 'repeater',
				'name'       => 'children',
				'title'      => esc_html__( 'Child elements', 'touchup-core' ),
				'items' => array(
					array(
						'field_type' => 'text',
						'name'       => 'item_url',
						'title'      => esc_html__( 'Link', 'touchup-core' )
					),
					array(
						'field_type'    => 'select',
						'name'          => 'item_target',
						'title'         => esc_html__( 'Link Target', 'touchup-core' ),
						'options'       => touchup_core_get_select_type_options_pool( 'link_target' ),
						'default_value' => '_self'
					),
					array(
						'field_type' => 'image',
						'name'       => 'item_image',
						'title'      => esc_html__( 'Image', 'touchup-core' )
					),
					array(
						'field_type' => 'image',
						'name'       => 'item_hover_image',
						'title'      => esc_html__( 'Hover Image', 'touchup-core' )
					),
					array(
						'field_type'  => 'text',
						'name'        => 'item_image_size',
						'title'       => esc_html__( 'Image Size', 'touchup-core' ),
						'description' => esc_html__( 'For predefined image sizes input thumbnail, medium, large or full. If you wish to set a custom image size, type in the desired image dimensions in pixels (e.g. 400x400).', 'touchup-core' ),
					),
					array(
						'field_type' => 'text',
						'name'       => 'item_image_margin_right',
						'title'      => esc_html__( 'Image Margin Right', 'touchup-core' )
					),
					array(
						'field_type' => 'text',
						'name'       => 'item_title',
						'title'      => esc_html__( 'Title', 'touchup-core' )
					),
					array(
						'field_type'    => 'select',
						'name'          => 'item_title_tag',
						'title'         => esc_html__( 'Title Tag', 'touchup-core' ),
						'options'       => touchup_core_get_select_type_options_pool( 'title_tag' ),
						'default_value' => 'h3'
					),
					array(
						'field_type' => 'textarea',
						'name'       => 'item_text',
						'title'      => esc_html__( 'Text', 'touchup-core' )
					),
					array(
						'field_type'    => 'select',
						'name'          => 'item_text_tag',
						'title'         => esc_html__( 'Text Tag', 'touchup-core' ),
						'options'       => touchup_core_get_select_type_options_pool( 'title_tag' ),
						'default_value' => 'p'
					),
					array(
						'field_type' => 'text',
						'name'       => 'item_text_margin_top',
						'title'      => esc_html__( 'Text Margin Top', 'touchup-core' )
					)
				)
			) );

			$this->map_extra_options();
		}
		
		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'touchup_core_icon_with_text_list', $params );
			$html = str_replace( "\n", '', $html );
			
			return $html;
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['items']          = $this->parse_repeater_items( $atts['children'] );
			$atts['this_object']    = $this;

			return touchup_core_get_template_part( 'shortcodes/icon-with-text-list', 'templates/icon-with-text-list', '', $atts );
		}
		
		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();
			
			$holder_classes[] = 'qodef-icon-with-text-list';
			$holder_classes[] = 'qodef-layout--columns';
			$holder_classes[] = ! empty( $atts['columns'] ) ? 'qodef-col-num--' . $atts['columns'] : '';

			return implode( ' ', $holder_classes );
		}

		public function get_item_data( $atts ) {

			$atts['item_link']         = ! empty( $atts['item_link'] ) ? $atts['item_link'] : '';
			$atts['item_target']       = ! empty( $atts['item_target'] ) ? $atts['item_target'] : '_self';
			$atts['item_image']        = $this->generate_image_params( $atts['item_image'] );
			$atts['item_hover_image']  = $this->generate_image_params( $atts['item_hover_image'] );
			$atts['item_image_size']   = $this->generate_image_size( $atts );
			$atts['item_image_styles'] = $this->get_image_styles( $atts );
			$atts['item_classes']      = $this->get_item_classes( $atts );
			$atts['item_title_tag']    = ! empty( $atts['item_title_tag'] ) ? $atts['item_title_tag'] : 'h3';
			$atts['item_text_tag']     = ! empty( $atts['item_text_tag'] ) ? $atts['item_text_tag'] : 'p';
			$atts['item_text_styles']  = $this->get_text_styles( $atts );

			return $atts;
		}

		private function get_item_classes( $atts ) {
			$item_classes = array( 'qodef-m-item' );

			if ( ! empty( $atts['item_hover_image']['image_id'] ) ) {
				$item_classes[] = 'qodef--hover-image-enabled';
			}

			return implode( ' ', $item_classes );
		}

		private function generate_image_params( $image ) {
			$output_image      = array();

			$image_id                 = $image;
			$output_image['image_id'] = intval( $image_id );
			$output_image['url']      = wp_get_attachment_image_src( $image_id, 'full' );
			$output_image['alt']      = get_post_meta( $image_id, '_wp_attachment_image_alt', true );

			return $output_image;
		}

		private function generate_image_size( $atts ) {
			$image_size = trim( $atts['item_image_size'] );
			preg_match_all( '/\d+/', $image_size, $matches ); /* check if numeral width and height are entered */
			if ( in_array( $image_size, array( 'thumbnail', 'thumb', 'medium', 'large', 'full' ) ) ) {
				return $image_size;
			} elseif ( ! empty( $matches[0] ) ) {
				return array(
					$matches[0][0],
					$matches[0][1]
				);
			} else {
				return 'full';
			}
		}

		private function get_image_styles( $atts ) {
			$styles = array();

			if ( $atts['item_image_margin_right'] !== '' ) {
				if ( qode_framework_string_ends_with_space_units( $atts['item_image_margin_right'] ) ) {
					$styles[] = 'margin-right: ' . $atts['item_image_margin_right'];
				} else {
					$styles[] = 'margin-right: ' . intval( $atts['item_image_margin_right'] ) . 'px';
				}
			}

			return $styles;
		}

		private function get_text_styles( $atts ) {
			$styles = array();

			if ( $atts['item_text_margin_top'] !== '' ) {
				if ( qode_framework_string_ends_with_space_units( $atts['item_text_margin_top'] ) ) {
					$styles[] = 'margin-top: ' . $atts['item_text_margin_top'];
				} else {
					$styles[] = 'margin-top: ' . intval( $atts['item_text_margin_top'] ) . 'px';
				}
			}

			return $styles;
		}
	}
}