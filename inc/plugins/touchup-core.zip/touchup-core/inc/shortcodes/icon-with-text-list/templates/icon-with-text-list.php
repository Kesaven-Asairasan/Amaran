<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-grid-inner qodef-m-items clear">
		<?php foreach ( $items as $item ) {
			$item = $this_object->get_item_data($item); ?>
			<div <?php qode_framework_class_attribute( $item['item_classes'] ); ?>>

				<?php if ( ! empty( $item['item_image']['image_id'] ) ) { ?>
					<span class="qodef-m-item-image" <?php qode_framework_inline_style( $item['item_image_styles'] ); ?>>
						<?php foreach (
							array(
								'original' => 'item_image',
								'hover'    => 'item_hover_image'
							) as $image_type => $image_source
						) {

							if ( ! empty( $item[ $image_source ]['image_id'] ) ) { ?>
								<span class="qodef-m-image-<?php echo esc_attr( $image_type ); ?>">
									<?php if ( is_array( $item['item_image_size'] ) && count( $item['item_image_size'] ) ) {
										echo qode_framework_generate_thumbnail( $item[ $image_source ]['image_id'], $item['item_image_size'][0], $item['item_image_size'][1] );
									} else {
										echo wp_get_attachment_image( $item[ $image_source ]['image_id'], $item['item_image_size'] );
									} ?>
								</span>
							<?php }
						} ?>
					</span>
				<?php } ?>

				<?php if ( ! empty( $item['item_title'] ) || ! empty( $item['item_text'] ) ) { ?>
					<div class="qodef-m-item-content">
						<?php if ( ! empty( $item['item_title'] ) ) { ?>
							<<?php echo touchup_core_escape_title_tag( $item['item_title_tag'] ); ?> class="qodef-m-item-title">
								<?php echo esc_html( $item['item_title'] ); ?>
							</<?php echo touchup_core_escape_title_tag( $item['item_title_tag'] ); ?>>
						<?php } ?>
						<?php if ( ! empty( $item['item_text'] ) ) { ?>
							<<?php echo touchup_core_escape_title_tag( $item['item_text_tag'] );; ?> class="qodef-m-item-text" <?php qode_framework_inline_style( $item['item_text_styles'] ); ?>>
								<?php echo esc_html( $item['item_text'] ); ?>
							</<?php echo touchup_core_escape_title_tag( $item['item_text_tag'] );; ?>>
						<?php } ?>
					</div>
				<?php } ?>

				<?php if ( ! empty( $item['item_url'] ) ) { ?>
					<a itemprop="url" href="<?php echo esc_url( $item['item_url'] ); ?>" class="qodef-m-item-link" target="<?php echo esc_attr( $item['item_target'] ); ?>"></a>
				<?php } ?>

			</div>
		<?php } ?>
	</div>
</div>