<?php

include_once TOUCHUP_CORE_SHORTCODES_PATH . '/icon-with-text-list/icon-with-text-list.php';