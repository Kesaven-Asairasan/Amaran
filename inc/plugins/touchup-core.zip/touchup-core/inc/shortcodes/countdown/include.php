<?php

include_once TOUCHUP_CORE_SHORTCODES_PATH . '/countdown/countdown.php';

foreach ( glob( TOUCHUP_CORE_SHORTCODES_PATH . '/countdown/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}