<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-m-line" <?php qode_framework_inline_style( $separator_styles ); ?>></div>
</div>