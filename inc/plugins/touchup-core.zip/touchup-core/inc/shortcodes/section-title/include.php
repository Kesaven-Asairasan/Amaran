<?php

include_once TOUCHUP_CORE_SHORTCODES_PATH . '/section-title/section-title.php';