<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php touchup_core_template_part( 'shortcodes/section-title', 'templates/parts/title', '', $params ) ?>
	<?php touchup_core_template_part( 'shortcodes/section-title', 'templates/parts/text', '', $params ) ?>
</div>