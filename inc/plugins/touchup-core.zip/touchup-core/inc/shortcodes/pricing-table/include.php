<?php

include_once TOUCHUP_CORE_SHORTCODES_PATH . '/pricing-table/pricing-table.php';

foreach ( glob( TOUCHUP_CORE_SHORTCODES_PATH . '/pricing-table/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}