<?php

include_once TOUCHUP_CORE_SHORTCODES_PATH . '/banner/banner.php';

foreach ( glob( TOUCHUP_CORE_INC_PATH . '/shortcodes/banner/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}