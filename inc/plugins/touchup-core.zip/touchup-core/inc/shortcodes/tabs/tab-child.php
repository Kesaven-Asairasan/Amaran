<?php

if ( ! function_exists( 'touchup_core_add_tabs_child_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param $shortcodes array
	 *
	 * @return array
	 */
	function touchup_core_add_tabs_child_shortcode( $shortcodes ) {
		$shortcodes[] = 'TouchUpCoreTabsChildShortcode';
		
		return $shortcodes;
	}
	
	add_filter( 'touchup_core_filter_register_shortcodes', 'touchup_core_add_tabs_child_shortcode' );
}

if ( class_exists( 'TouchUpCoreShortcode' ) ) {
	class TouchUpCoreTabsChildShortcode extends TouchUpCoreShortcode {
		
		public function map_shortcode() {
			$this->set_shortcode_path( TOUCHUP_CORE_SHORTCODES_URL_PATH . '/tabs' );
			$this->set_base( 'touchup_core_tabs_child' );
			$this->set_name( esc_html__( 'Tabs Child', 'touchup-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds tab child to tabs holder', 'touchup-core' ) );
			$this->set_category( esc_html__( 'TouchUp Core', 'touchup-core' ) );
			$this->set_is_child_shortcode( true );
			$this->set_parent_elements( array(
				'touchup_core_tabs'
			) );
			$this->set_is_parent_shortcode( true );
			$this->set_option( array(
				'field_type' => 'text',
				'name'       => 'tab_title',
				'title'      => esc_html__( 'Title', 'touchup-core' ),
			) );
			$this->set_option( array(
				'field_type'    => 'text',
				'name'          => 'layout',
				'title'         => esc_html__( 'Layout', 'touchup-core' ),
				'default_value' => '',
				'visibility'    => array('map_for_page_builder' => false)
			) );
		}
		
		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();
			
			$rand_number       = rand( 0, 1000 );
			$atts['tab_title'] = $atts['tab_title'] . '-' . $rand_number;
			$atts['content']   = $content;

			return touchup_core_get_template_part( 'shortcodes/tabs', 'variations/'.$atts['layout'].'/templates/child', '', $atts );
		}
	}
}