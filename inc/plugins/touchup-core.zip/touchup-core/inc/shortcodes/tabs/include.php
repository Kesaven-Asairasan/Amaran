<?php

include_once TOUCHUP_CORE_SHORTCODES_PATH . '/tabs/tab.php';
include_once TOUCHUP_CORE_SHORTCODES_PATH . '/tabs/tab-child.php';

foreach ( glob( TOUCHUP_CORE_SHORTCODES_PATH . '/tabs/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}