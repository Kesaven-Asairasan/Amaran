<?php

if ( ! function_exists( 'touchup_core_add_blog_list_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param $widgets array
	 *
	 * @return array
	 */
	function touchup_core_add_blog_list_widget( $widgets ) {
		$widgets[] = 'TouchUpCoreBlogListWidget';
		
		return $widgets;
	}
	
	add_filter( 'touchup_core_filter_register_widgets', 'touchup_core_add_blog_list_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class TouchUpCoreBlogListWidget extends QodeFrameworkWidget {
		
		public function map_widget() {
			$this->set_widget_option(
				array(
					'field_type' => 'text',
					'name'       => 'widget_title',
					'title'      => esc_html__( 'Title', 'touchup-core' )
				)
			);
			$widget_mapped = $this->import_shortcode_options( array(
				'shortcode_base' => 'touchup_core_blog_list'
			) );
			
			if ( $widget_mapped ) {
				$this->set_base( 'touchup_core_blog_list' );
				$this->set_name( esc_html__( 'TouchUp Blog List', 'touchup-core' ) );
				$this->set_description( esc_html__( 'Display a list of blog posts', 'touchup-core' ) );
			}
		}
		
		public function render( $atts ) {
			$params = $this->generate_string_params( $atts );
			
			echo do_shortcode( "[touchup_core_blog_list $params]" ); // XSS OK
		}
	}
}
