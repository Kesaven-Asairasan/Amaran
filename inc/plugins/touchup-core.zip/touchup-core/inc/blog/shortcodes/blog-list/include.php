<?php

include_once TOUCHUP_CORE_INC_PATH . '/blog/shortcodes/blog-list/blog-list.php';

foreach ( glob( TOUCHUP_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}