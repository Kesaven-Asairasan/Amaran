<div class="qodef-fullscreen-search-holder qodef-m">
	<div class="qodef-m-inner">
		<form action="<?php echo esc_url( home_url( '/' ) ); ?>" class="qodef-m-form" method="get">
			<input type="text" placeholder="<?php esc_attr_e( 'Search for...', 'touchup-core' ); ?>" name="s" class="qodef-m-form-field" autocomplete="off" required/>
			<div class="qodef-m-form-line"></div>
			<a class="qodef-search-close qodef-m-close <?php echo touchup_core_get_open_close_icon_class('qodef_search_icon_source','qodef-search-close'); ?>" href="javascript:void(0)">
		        <?php echo touchup_core_get_search_icon_html(true); ?>
		    </a>
		</form>
	</div>
</div>