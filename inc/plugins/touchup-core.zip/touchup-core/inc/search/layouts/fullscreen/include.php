<?php

include_once TOUCHUP_CORE_INC_PATH . '/search/layouts/fullscreen/helper.php';
include_once TOUCHUP_CORE_INC_PATH . '/search/layouts/fullscreen/fullscreen.php';