<?php

include_once TOUCHUP_CORE_INC_PATH . '/search/layouts/covers-header/helper.php';
include_once TOUCHUP_CORE_INC_PATH . '/search/layouts/covers-header/covers-header.php';