<?php

include_once TOUCHUP_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/system-info.php';