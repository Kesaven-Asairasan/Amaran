<?php

include_once TOUCHUP_CORE_INC_PATH . '/wpbakery/helper.php';