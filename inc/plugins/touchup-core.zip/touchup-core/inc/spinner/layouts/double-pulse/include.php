<?php

include_once TOUCHUP_CORE_INC_PATH . '/spinner/layouts/double-pulse/helper.php';