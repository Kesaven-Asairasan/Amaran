<?php

include_once TOUCHUP_CORE_INC_PATH . '/spinner/layouts/predefined-svg/helper.php';