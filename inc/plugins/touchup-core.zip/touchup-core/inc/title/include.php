<?php

include_once TOUCHUP_CORE_INC_PATH . '/title/helper.php';
include_once TOUCHUP_CORE_INC_PATH . '/title/title.php';
include_once TOUCHUP_CORE_INC_PATH . '/title/titles.php';