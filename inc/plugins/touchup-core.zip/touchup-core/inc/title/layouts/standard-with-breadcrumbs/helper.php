<?php

if ( ! function_exists( 'touchup_core_register_standard_with_breadcrumbs_title_layout' ) ) {
	function touchup_core_register_standard_with_breadcrumbs_title_layout( $layouts ) {
		$layouts['standard-with-breadcrumbs'] = 'TouchUpCoreStandardWithBreadcrumbsTitle';

		return $layouts;
	}

	add_filter( 'touchup_core_filter_register_title_layouts', 'touchup_core_register_standard_with_breadcrumbs_title_layout' );
}

if ( ! function_exists( 'touchup_core_add_standard_with_breadcrumbs_title_layout_option' ) ) {
	/**
	 * Function that set new value into title layout options map
	 *
	 * @param $layouts array - module layouts
	 *
	 * @return array
	 */
	function touchup_core_add_standard_with_breadcrumbs_title_layout_option( $layouts ) {
		$layouts['standard-with-breadcrumbs'] = esc_html__( 'Standard with breadcrumbs', 'touchup-core' );

		return $layouts;
	}

	add_filter( 'touchup_core_filter_title_layout_options', 'touchup_core_add_standard_with_breadcrumbs_title_layout_option' );
}

