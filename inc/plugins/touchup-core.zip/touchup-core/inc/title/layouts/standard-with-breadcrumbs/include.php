<?php

include_once TOUCHUP_CORE_INC_PATH . '/title/layouts/standard-with-breadcrumbs/helper.php';
include_once TOUCHUP_CORE_INC_PATH . '/title/layouts/standard-with-breadcrumbs/standard-with-breadcrumbs-title.php';