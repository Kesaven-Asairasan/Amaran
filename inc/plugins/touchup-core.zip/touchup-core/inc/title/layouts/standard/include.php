<?php

include_once TOUCHUP_CORE_INC_PATH . '/title/layouts/standard/helper.php';
include_once TOUCHUP_CORE_INC_PATH . '/title/layouts/standard/standard-title.php';
include_once TOUCHUP_CORE_INC_PATH . '/title/layouts/standard/dashboard/meta-box/standard-title-meta-box.php';