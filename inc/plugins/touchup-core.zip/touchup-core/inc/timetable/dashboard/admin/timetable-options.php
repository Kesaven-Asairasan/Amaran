<?php

if ( ! function_exists( 'touchup_core_add_timetable_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function touchup_core_add_timetable_options() {
		$qode_framework = qode_framework_get_framework_root();
		
		$page = $qode_framework->add_options_page(
			array(
				'scope'       => TOUCHUP_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'timetable',
				'icon'        => 'fa fa-book',
				'title'       => esc_html__( 'Timetable', 'touchup-core' ),
				'description' => esc_html__( 'Global Timetable Options', 'touchup-core' )
			)
		);
		
		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_timetable_enable',
					'title'       => esc_html__( 'Enable custom style', 'touchup-core' ),
					'description' => esc_html__( 'This option will enable custom style for timetable', 'touchup-core' ),
					'options'     => array(
						'yes'        => esc_html__( 'Yes', 'touchup-core' ),
						'no' => esc_html__( 'no', 'touchup-core' )
					)
				)
			);
			
			// Hook to include additional options after module options
			do_action( 'touchup_core_action_after_timetable_options_map', $page );
		}
	}
	
	add_action( 'touchup_core_action_default_options_init', 'touchup_core_add_timetable_options', touchup_core_get_admin_options_map_position( 'timetable' ) );
}