<?php

if ( ! function_exists( 'touchup_core_include_timetable_shortcodes' ) ) {
	/**
	 * Function that includes shortcodes
	 */
	function touchup_core_include_timetable_shortcodes() {
		foreach ( glob( TOUCHUP_CORE_INC_PATH . '/timetable/shortcodes/*/include.php' ) as $shortcode ) {
			include_once $shortcode;
		}
	}
	
	add_action( 'qode_framework_action_before_shortcodes_register', 'touchup_core_include_timetable_shortcodes' );
}

if ( ! function_exists( 'touchup_core_is_timetable_installed' ) ) {
	/**
	 * Function that checks if Booked plugin is installed
	 * @return bool
	 *
	 * @version 0.1
	 */
	function touchup_core_is_timetable_installed() {
		return defined( 'TIMETABLE_VERSION' );
	}
}

if ( ! function_exists( 'touchup_core_timetable_body_classes' ) ) {
	
	function touchup_core_timetable_body_classes( $classes ) {
		$custom_style = touchup_core_get_post_value_through_levels( 'qodef_timetable_enable' );
		
		if ( $custom_style == 'yes' ) {
			$classes[] = 'qodef-timetable-enable';
		}
		
		return $classes;
	}
	
	add_filter( 'body_class', 'touchup_core_timetable_body_classes' );
}