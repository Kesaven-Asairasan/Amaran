<?php

if ( ! function_exists( 'touchup_core_add_general_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function touchup_core_add_general_options( $page ) {

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_main_color',
					'title'       => esc_html__( 'Main Color', 'touchup-core' ),
					'description' => esc_html__( 'Choose the most dominant theme color', 'touchup-core' )
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_page_background_color',
					'title'       => esc_html__( 'Page Background Color', 'touchup-core' ),
					'description' => esc_html__( 'Set background color', 'touchup-core' )
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_page_background_image',
					'title'       => esc_html__( 'Page Background Image', 'touchup-core' ),
					'description' => esc_html__( 'Set background image', 'touchup-core' )
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_repeat',
					'title'       => esc_html__( 'Page Background Image Repeat', 'touchup-core' ),
					'description' => esc_html__( 'Set background image repeat', 'touchup-core' ),
					'options'     => array(
						''          => esc_html__( 'Default', 'touchup-core' ),
						'no-repeat' => esc_html__( 'No Repeat', 'touchup-core' ),
						'repeat'    => esc_html__( 'Repeat', 'touchup-core' ),
						'repeat-x'  => esc_html__( 'Repeat-x', 'touchup-core' ),
						'repeat-y'  => esc_html__( 'Repeat-y', 'touchup-core' )
					)
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_size',
					'title'       => esc_html__( 'Page Background Image Size', 'touchup-core' ),
					'description' => esc_html__( 'Set background image size', 'touchup-core' ),
					'options'     => array(
						''        => esc_html__( 'Default', 'touchup-core' ),
						'contain' => esc_html__( 'Contain', 'touchup-core' ),
						'cover'   => esc_html__( 'Cover', 'touchup-core' )
					)
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_attachment',
					'title'       => esc_html__( 'Page Background Image Attachment', 'touchup-core' ),
					'description' => esc_html__( 'Set background image attachment', 'touchup-core' ),
					'options'     => array(
						''       => esc_html__( 'Default', 'touchup-core' ),
						'fixed'  => esc_html__( 'Fixed', 'touchup-core' ),
						'scroll' => esc_html__( 'Scroll', 'touchup-core' )
					)
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_page_content_padding',
					'title'       => esc_html__( 'Page Content Padding', 'touchup-core' ),
					'description' => esc_html__( 'Set padding that will be applied for page content in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'touchup-core' )
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_page_content_padding_mobile',
					'title'       => esc_html__( 'Page Content Padding Mobile', 'touchup-core' ),
					'description' => esc_html__( 'Set padding that will be applied for page content on mobile screens (1024px and below) in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'touchup-core' )
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_boxed',
					'title'         => esc_html__( 'Boxed Layout', 'touchup-core' ),
					'description'   => esc_html__( 'Set boxed layout', 'touchup-core' ),
					'default_value' => 'no'
				)
			);

			$boxed_section = $page->add_section_element(
				array(
					'name'       => 'qodef_boxed_section',
					'title'      => esc_html__( 'Boxed Layout Section', 'touchup-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_boxed' => array(
								'values'        => 'no',
								'default_value' => ''
							)
						)
					)
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_boxed_background_color',
					'title'       => esc_html__( 'Boxed Background Color', 'touchup-core' ),
					'description' => esc_html__( 'Set boxed background color', 'touchup-core' )
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_passepartout',
					'title'         => esc_html__( 'Passepartout', 'touchup-core' ),
					'description'   => esc_html__( 'Enabling this option will display a passepartout around website content', 'touchup-core' ),
					'default_value' => 'no'
				)
			);

			$passepartout_section = $page->add_section_element(
				array(
					'name'       => 'qodef_passepartout_section',
					'title'      => esc_html__( 'Passepartout Section', 'touchup-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_passepartout' => array(
								'values'        => 'no',
								'default_value' => ''
							)
						)
					)
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_passepartout_color',
					'title'       => esc_html__( 'Passepartout Color', 'touchup-core' ),
					'description' => esc_html__( 'Choose background color for passepartout', 'touchup-core' )
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_passepartout_image',
					'title'       => esc_html__( 'Passepartout Background Image', 'touchup-core' ),
					'description' => esc_html__( 'Set background image for passepartout', 'touchup-core' )
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_passepartout_size',
					'title'       => esc_html__( 'Passepartout Size', 'touchup-core' ),
					'description' => esc_html__( 'Enter size amount for passepartout', 'touchup-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px or %', 'touchup-core' )
					)
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_passepartout_size_responsive',
					'title'       => esc_html__( 'Passepartout Responsive Size', 'touchup-core' ),
					'description' => esc_html__( 'Enter size amount for passepartout for smaller screens (1024px and below)', 'touchup-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px or %', 'touchup-core' )
					)
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_content_width',
					'title'         => esc_html__( 'Initial Width of Content', 'touchup-core' ),
					'description'   => esc_html__( 'Choose the initial width of content which is in grid (applies to pages set to "Default Template" and rows set to "In Grid")', 'touchup-core' ),
					'options'       => touchup_core_get_select_type_options_pool( 'content_width', false ),
					'default_value' => '1100'
				)
			);

			// Hook to include additional options after module options
			do_action( 'touchup_core_action_after_general_options_map', $page );

			$page->add_field_element(
				array(
					'field_type'  => 'textarea',
					'name'        => 'qodef_custom_js',
					'title'       => esc_html__( 'Custom JS', 'touchup-core' ),
					'description' => esc_html__( 'Enter your custom Javascript here', 'touchup-core' )
				)
			);
		}
	}

	add_action( 'touchup_core_action_default_options_init', 'touchup_core_add_general_options', touchup_core_get_admin_options_map_position( 'general' ) );
}